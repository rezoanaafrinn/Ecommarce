﻿namespace eticket.Data
{
    public enum MovieCategory
    {
        Action=1,
        Comedy,
        Drama,
        Documentary,
        Horror,
        Cartoon
    }
}
