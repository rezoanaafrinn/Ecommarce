﻿namespace eticket.Models
{
    public class Actor_movie
    {
        public int MovieId { get; set; }
        public Movie Movies { get; set; }
        public int ActorId { get; set; }
        public Actor Actors { get; set; }
    }
}
