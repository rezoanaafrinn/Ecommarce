﻿using eticket.Data;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace eticket.Models
{
    public class Movie
    {
        public int Id { get; set; }

        [Display(Name = "Movie Name")]
        public string Name { get; set; }

        [Display(Name = "Description")]
        public string Description { get; set; }

        [Display(Name = "Price")]
        public double Price { get; set; }

        [Display(Name = "ImageURL")]
        public string ImageURL { get; set; }
        public DateTime Startime { get; set; }
        public DateTime Endtime { get; set; }
        public MovieCategory MovieCategory { get; set; }

        //Relationships
        public List<Actor_movie> Actor_Movie { get; set; }

        //Cinema

        public int CinemaId { get; set; }
        [ForeignKey("CinemaId")]
        public Cinema Cinemas { get; set; }

        //Producer

        public int ProducerId { get; set; }
        [ForeignKey("ProducerId")]
        public Producer Producers { get; set; }
        
    }
}
